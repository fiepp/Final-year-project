"""
Quantile Transformer for request-count forecasting
==================================================

用于预测未来 horizon 个 20s 窗口的请求量 / QPS，默认 horizon=2。

关键设计：
1. 训练目标使用归一化后的 y，模型输出也是归一化空间的 q10/q50/q90。
2. q50 使用 residual head：q50 = last_qps_norm + delta。
   这样预测会锚定最近一个窗口，避免预测退化成大段均值平台。
3. q10 <= q50 <= q90 通过 softplus 保证。
"""

import math
from typing import Iterable, Optional, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class PositionalEncoding(nn.Module):
    """正弦位置编码。"""

    def __init__(self, d_model: int, max_len: int = 1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float()
            * -(math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, : x.size(1), :]


class QuantileQPSTransformer(nn.Module):
    """
    Multi-window non-crossing quantile Transformer。

    输入:
        x: (batch, lookback, feature_dim)，其中第 0 个特征必须是归一化后的 qps。

    输出:
        quantiles: (batch, horizon, 3)，最后一维为 [q10, q50, q90]。
        注意：输出处于归一化 target 空间，evaluate/inference 会反归一化。
    """

    def __init__(
        self,
        feature_dim: int = 1,
        d_model: int = 128,
        n_heads: int = 8,
        n_layers: int = 3,
        d_ff: int = 512,
        dropout: float = 0.1,
        lookback: int = 400,
        horizon: int = 2,
        target_feature_index: int = 0,
        residual_q50: bool = True,
    ):
        super().__init__()
        if horizon < 1:
            raise ValueError("horizon 必须 >= 1。")
        if target_feature_index < 0 or target_feature_index >= feature_dim:
            raise ValueError(
                f"target_feature_index={target_feature_index} 超出 feature_dim={feature_dim} 范围。"
            )

        self.feature_dim = feature_dim
        self.lookback = lookback
        self.horizon = horizon
        self.d_model = d_model
        self.target_feature_index = target_feature_index
        self.residual_q50 = residual_q50

        self.embedding = nn.Linear(feature_dim, d_model)
        self.pos_encoding = PositionalEncoding(d_model=d_model, max_len=max(lookback, 1000))

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)

        # 每个未来窗口输出 3 个量：delta_or_median_raw, lower_dev_raw, upper_dev_raw
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, horizon * 3),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.embedding(x)
        h = self.pos_encoding(h)
        h = self.transformer(h)
        h_last = h[:, -1, :]

        out = self.head(h_last).view(-1, self.horizon, 3)  # (batch, horizon, 3)

        center_raw = out[:, :, 0]

        if self.residual_q50:
            # 多步预测仍以最近一个窗口为锚点，每个 horizon 学自己的 delta。
            last_target_norm = x[:, -1, self.target_feature_index].unsqueeze(1)
            q50 = last_target_norm + center_raw
        else:
            q50 = center_raw

        # q50 是归一化空间的值：
        # 低原始 QPS 通常对应负的 q50_norm，所以不能用 abs(q50)，否则低谷也会被放大。
        # 使用 exp(0.25 * q50)：
        #   q50_norm < 0  -> scale < 1，低 QPS 区间收窄
        #   q50_norm > 0  -> scale > 1，高 QPS 区间适度放宽
        # clamp 防止区间过窄或过宽。
        level_scale = torch.clamp(torch.exp(0.25 * q50), min=0.6, max=2.0)

        lower_dev = F.softplus(out[:, :, 1]) * level_scale + 1e-6
        upper_dev = F.softplus(out[:, :, 2]) * level_scale + 1e-6
        q10 = q50 - lower_dev
        q90 = q50 + upper_dev

        quantiles = torch.stack([q10, q50, q90], dim=-1)
        return quantiles


def quantile_loss(
    y_true: torch.Tensor,
    y_pred: torch.Tensor,
    taus: Sequence[float] = (0.1, 0.5, 0.9),
    weights: Sequence[float] = (0.5,1.4,0.8),
    horizon_weights: Optional[Sequence[float]] = None,
) -> torch.Tensor:
    """
    Pinball / quantile loss。

    默认稍微更重视 q50/q90：q50 控制点预测，q90 控制保守规划上界。
    y_true 和 y_pred 都应处于归一化 target 空间。
    """
    if y_true.dim() == 1:
        y_true = y_true.unsqueeze(1)
    if y_pred.dim() != 3 or y_pred.shape[-1] != 3:
        raise ValueError(f"y_pred 应为 (batch, horizon, 3)，当前 shape={tuple(y_pred.shape)}")

    horizon = y_true.shape[1]
    if horizon_weights is None:
        h_weights = torch.ones(1, horizon, dtype=y_true.dtype, device=y_true.device)
    else:
        if len(horizon_weights) != horizon:
            raise ValueError(
                f"horizon_weights 长度必须等于 horizon。当前 horizon={horizon}, "
                f"horizon_weights 长度={len(horizon_weights)}"
            )
        h_weights = torch.tensor(horizon_weights, dtype=y_true.dtype, device=y_true.device).view(1, horizon)

    total = 0.0

    # 正常 quantile loss，不再对所有样本都强行 peak 加权
    for i, (tau, w) in enumerate(zip(taus, weights)):
        diff = y_true - y_pred[:, :, i]
        loss = torch.maximum(tau * diff, (tau - 1.0) * diff)
        total = total + w * (loss * h_weights).mean()

    q10 = y_pred[:, :, 0]
    q50 = y_pred[:, :, 1]
    q90 = y_pred[:, :, 2]

    # y_true 是归一化空间：
    # y_true > 0 通常表示高于平均负载
    # y_true < 0 通常表示低于平均负载

    # 高峰 gate：只在高 QPS 区间明显生效
    peak_gate = torch.sigmoid(6.0 * (y_true - 0.4))

    # 低谷 gate：只在低 QPS 区间明显生效
    valley_gate = torch.sigmoid(6.0 * (-0.2 - y_true))

    # 1. 高峰低估惩罚：解决峰值跟不上
    under_error = F.relu(y_true - q50)
    peak_under_loss = (under_error * h_weights * peak_gate).mean()

    # 2. 低谷高估惩罚：解决 q50 在低谷偏高
    over_error = F.relu(q50 - y_true)
    valley_over_loss = (over_error * h_weights * valley_gate).mean()

    # 3. 低谷区间宽度惩罚：轻微压 q90，避免低谷 q90 太高
    width = q90 - q10
    low_width_loss = (width * h_weights * valley_gate).mean()

    total = (
            total
            + 0.45 * peak_under_loss
            + 0.35 * valley_over_loss
            + 0.05 * low_width_loss
    )

    return total


def _ensure_2d(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a)
    if a.ndim == 1:
        return a.reshape(-1, 1)
    return a


def compute_metrics(y_true, y_pred):
    """
    计算原始量纲下的评估指标。

    Args:
        y_true: (N, 1) 或 (N,)
        y_pred: (N, 1, 3)
    """
    y_true = _ensure_2d(np.asarray(y_true))
    y_pred = np.asarray(y_pred)

    q10 = y_pred[..., 0]
    q50 = y_pred[..., 1]
    q90 = y_pred[..., 2]

    mae = np.mean(np.abs(y_true - q50))
    rmse = np.sqrt(np.mean((y_true - q50) ** 2))
    mape = np.mean(np.abs(y_true - q50) / (np.abs(y_true) + 1e-6)) * 100

    inside = (y_true >= q10) & (y_true <= q90)
    picp = inside.mean() * 100
    mpiw = np.mean(q90 - q10)
    cov_q10 = np.mean(y_true <= q10) * 100
    cov_q90 = np.mean(y_true <= q90) * 100

    pinball_q10 = np.mean(np.maximum(0.1 * (y_true - q10), -0.9 * (y_true - q10)))
    pinball_q50 = np.mean(np.maximum(0.5 * (y_true - q50), -0.5 * (y_true - q50)))
    pinball_q90 = np.mean(np.maximum(0.9 * (y_true - q90), -0.1 * (y_true - q90)))

    return {
        "MAE_q50": float(mae),
        "RMSE_q50": float(rmse),
        "MAPE_q50": float(mape),
        "PICP_80": float(picp),
        "MPIW": float(mpiw),
        "Coverage_q10": float(cov_q10),
        "Coverage_q90": float(cov_q90),
        "Pinball_q10": float(pinball_q10),
        "Pinball_q50": float(pinball_q50),
        "Pinball_q90": float(pinball_q90),
    }


class ConfidenceCalculator:
    """基于 q10-q90 相对宽度计算 confidence。"""

    def __init__(self, epsilon: float = 1e-6, qps_floor: float = 20.0):
        self.epsilon = epsilon
        self.qps_floor = float(qps_floor)
        self.U_ref = None

    def _relative_width(self, q10, q50, q90):
        denom = np.abs(q50) + self.qps_floor + self.epsilon
        return (q90 - q10) / denom

    def calibrate(self, val_predictions):
        val_predictions = np.asarray(val_predictions)
        q10 = val_predictions[..., 0]
        q50 = val_predictions[..., 1]
        q90 = val_predictions[..., 2]
        U = self._relative_width(q10, q50, q90)
        self.U_ref = float(np.percentile(U.reshape(-1), 90))
        self.U_ref = max(self.U_ref, self.epsilon)
        print(
            f"[ConfidenceCalculator] U_ref calibrated = {self.U_ref:.6f}, "
            f"qps_floor={self.qps_floor:.2f}"
        )

    def compute(self, q10, q50, q90):
        if self.U_ref is None:
            raise RuntimeError("Call calibrate() first!")
        q10 = np.asarray(q10)
        q50 = np.asarray(q50)
        q90 = np.asarray(q90)
        U = self._relative_width(q10, q50, q90)
        C = np.exp(-U / (self.U_ref + self.epsilon))
        return np.clip(C, 0.0, 1.0)
